public interface EmployeeCompensation{
	
	public abstract double CalculateTotalCompensation();
}//end bracket 