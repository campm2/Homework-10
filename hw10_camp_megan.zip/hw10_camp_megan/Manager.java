import java.io.PrintWriter;
public class Manager extends Employee implements EmployeeCompensation{
	private double stockDividend_=0;
	
	//Constructor
	//#####################
	/**
	 * @param ID
	 * @param yearHired
	 * @param baseSalary
	 * @param stockDividend
	 */
	public Manager(int ID, int yearHired, double baseSalary,double stockDividend) {
		setID(ID);
		setYearHired(yearHired);
		setBaseSalary(baseSalary);
		stockDividend_=stockDividend;
	}//end bracket of arguement constructor
	/**
	 * 
	 */
	public Manager() {
		stockDividend_=0;
	}//end bracket of constructor
	
	//Setter and Getters
	//#######################
	
	/**
	 * @return the stockDividend_
	 */
	public double getStockDividend() {
		return stockDividend_;
	}//end bracket of stockDividend getter

	/**
	 * @param stockDividend_ the stockDividend_ to set
	 */
	public void setStockDividend(double stockDividend) {
		
		stockDividend_ = stockDividend;
	}//end bracket of stockDividend setter
	/**
	 * @param pw
	 */
	public void ShowDividend(PrintWriter pw) {
		System.out.printf("Dividend is $%,.0f!\n",getStockDividend());
		pw.printf("Dividend is $%,.0f!\n",getStockDividend());
		
	}//end bracket of ShowDividend()
	/**
	 * return string 
	 */
	public String toString() {
		return String.format ("This is a Manager.ID is %d, hired since %d, and stock dividend is $%,.0f",getID(),getYearHired(),stockDividend_);
	}//end bracket of toString Method
	/**
	 * @return string
	 */
	public String EmployeeInfo() {
		return String.format("%d\t%d\t\tManager\t$%,.0f\t\t$%,.0f\n",getID(),getYearHired(),getBaseSalary(),CalculateTotalCompensation());
	}//end bracket of EmployeeInfo()
	/**
	 * return totalCompensation_
	 */
	public double CalculateTotalCompensation() {
		totalCompensation_=(getBaseSalary()+stockDividend_);
		return totalCompensation_;
		
	}//end bracket of CalculateTotalCompensation()
	
}//end bracket of class