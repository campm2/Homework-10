public class JuniorEmployee extends Employee implements EmployeeCompensation {
	private double commission_=0;
	
	// constructors
	/**
	 * @param ID
	 * @param yearHired
	 * @param baseSalary
	 * @param commission
	 */
	public JuniorEmployee(int ID,int yearHired,double baseSalary,double commission) {
		setID(ID);
		setYearHired(yearHired);
		setBaseSalary(baseSalary);
		commission_=commission;
	}//end bracket of arguement constuctor
	/**
	 * 
	 */
	public JuniorEmployee(){
		commission_=0;
	}//end bracket of constructor
	//Setter and Getter
	//############################
	
	/**
	 * @return the commission_
	 */
	public double getCommission() {
		return commission_;
	}//end bracket of commission getter

	/**
	 * @param commission_ 
	 */
	public void setCommission(double commission) {
		commission_ = commission;
	}//end bracket of commission setter
	/**
	 * @return totalCompensation_
	 */
	public double CalculateTotalCompensation() {
		totalCompensation_=(getBaseSalary()+getCommission());
		return totalCompensation_;
		
	}//end bracket of CalculateTotalCompensation() 
	
	//to String Method
	//###############################
	/**
	 * @return String
	 */
	public String toString() {
		return String.format ("This is a Junior Employee.ID is %d, hired since %d, and commission is $%,.0f",getID(),getYearHired(),commission_);
	}//end bracket of toString Method
	/** 
	 * @return String
	 */
	public String EmployeeInfo() {
		return String.format("%d\t%d\t\tJunior\t$%,.0f\t\t$%,.0f\n",getID(),getYearHired(),getBaseSalary(),CalculateTotalCompensation());
	}//end bracket of EmployeeInfo()
	
	
	
}