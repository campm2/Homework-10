public class SeniorEmployee extends Employee implements EmployeeCompensation{
	private double annualBonus_=0;
	
	//Constructors
	//################
	/**
	 * @param ID
	 * @param yearHired
	 * @param baseSalary
	 * @param annualBonus
	 */
	public SeniorEmployee(int ID, int yearHired, double baseSalary,double annualBonus) {
		setID(ID);
		setYearHired(yearHired);
		setBaseSalary(baseSalary);
		annualBonus_=annualBonus;
	}
	/**
	 * 
	 */
	public SeniorEmployee() {
		annualBonus_=0;
	}//end bracket of constructor
	//Setter and Getter
	//###################
	
	/**
	 * @return the annualBonus_
	 */
	public double getAnnualBonus() {
		return annualBonus_;
	}//end bracket of annualBonus getter
	/**
	 * @param annualBonus_ the annualBonus_ to set
	 */
	public void setAnnualBonus(double annualBonus) {
		annualBonus_ = annualBonus;
	}//end bracket of annualBonus setter
	
	//toString method
	/**
	 * @return string
	 */
	public String toString() {
		return String.format ("This is a Senior Employee.ID is %d, hired since %d, and annual bonus is $%,.0f",getID(),getYearHired(),annualBonus_);
	}//end bracket of toString Method
	/**
	 * @return String
	 */
	public String EmployeeInfo() {
		return String.format("%d\t%d\t\tSenior\t$%,.0f\t\t$%,.0f\n",getID(),getYearHired(),getBaseSalary(),CalculateTotalCompensation());
	}//end bracket of EmployeeInfo()
	/**
	 * @return totalCompensation_
	 */
	public double CalculateTotalCompensation() {
		totalCompensation_=(getBaseSalary()+getAnnualBonus());
		return totalCompensation_;
	}//end bracket of CalcualteTotalCompensation
}//end bracket of class